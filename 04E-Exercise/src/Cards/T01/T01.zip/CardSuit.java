package Cards.T01;

public enum CardSuit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}
