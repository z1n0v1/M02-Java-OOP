public class Main {
    public static void main(String[] args) {
        Person person = new Person("asd", "asd", 11, 459.99);
        System.out.println(person);
    }
}
