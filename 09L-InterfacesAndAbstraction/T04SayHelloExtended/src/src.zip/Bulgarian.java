public class Bulgarian extends BasePerson {
    public Bulgarian(String name) {
        super(name);
    }

    public String sayHallo() {
        return "Здравей";
    }
}
