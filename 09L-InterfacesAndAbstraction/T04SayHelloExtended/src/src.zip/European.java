public class European extends BasePerson {
    public European(String name) {
        super(name);
    }
}
