public interface SpecialisedSoldier extends Private {
    Corps getCorps();
}
