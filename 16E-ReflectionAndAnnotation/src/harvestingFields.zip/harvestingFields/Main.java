package harvestingFields;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Predicate;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Field[] fields = RichSoilLand.class.getDeclaredFields();

        String input;
        while (!"HARVEST".equals(input = reader.readLine())) {
            switch (input) {
                case "private":
                    for (Field field : getFieldsByModifier(fields, Modifier::isPrivate)) {
                        printField(field);
                    }
                    break;
                case "protected":
                    for (Field field : getFieldsByModifier(fields, Modifier::isProtected)) {
                        printField(field);
                    }
                    break;
                case "public":
                    for (Field field : getFieldsByModifier(fields, Modifier::isPublic)) {
                        printField(field);
                    }
                    break;
                case "all":
                    for (Field field : fields) {
                        printField(field);
                    }
            }
        }

    }

    public static void printField(Field field) {
        System.out.printf("%s %s %s%n",
                Modifier.toString(field.getModifiers()), field.getType().getSimpleName(), field.getName());
    }

    private static Field[] getFieldsByModifier(Field[] fields, Predicate<Integer> predicate) {
        return Arrays.stream(fields).filter(f -> predicate.test(f.getModifiers())).toArray(Field[]::new);

    }


}
